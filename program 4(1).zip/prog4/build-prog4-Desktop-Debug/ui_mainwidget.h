/********************************************************************************
** Form generated from reading UI file 'mainwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWIDGET_H
#define UI_MAINWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWidget
{
public:
    QRadioButton *rdbBasic;
    QRadioButton *rdbWand;
    QRadioButton *rdbTrack;
    QPushButton *btnMove;
    QPushButton *btnDelete;
    QPushButton *btnUndo;
    QPushButton *btnWall;
    QPushButton *btnBomb;
    QPushButton *btnRobot;
    QWidget *wdgWorld;
    QPushButton *btnAnimate;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QWidget *MainWidget)
    {
        if (MainWidget->objectName().isEmpty())
            MainWidget->setObjectName(QStringLiteral("MainWidget"));
        MainWidget->resize(778, 544);
        rdbBasic = new QRadioButton(MainWidget);
        rdbBasic->setObjectName(QStringLiteral("rdbBasic"));
        rdbBasic->setGeometry(QRect(20, 380, 116, 22));
        rdbWand = new QRadioButton(MainWidget);
        rdbWand->setObjectName(QStringLiteral("rdbWand"));
        rdbWand->setGeometry(QRect(20, 350, 116, 22));
        rdbTrack = new QRadioButton(MainWidget);
        rdbTrack->setObjectName(QStringLiteral("rdbTrack"));
        rdbTrack->setGeometry(QRect(20, 320, 116, 22));
        btnMove = new QPushButton(MainWidget);
        btnMove->setObjectName(QStringLiteral("btnMove"));
        btnMove->setGeometry(QRect(10, 260, 61, 51));
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/pointer.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnMove->setIcon(icon);
        btnMove->setIconSize(QSize(60, 60));
        btnMove->setCheckable(true);
        btnDelete = new QPushButton(MainWidget);
        btnDelete->setObjectName(QStringLiteral("btnDelete"));
        btnDelete->setGeometry(QRect(80, 260, 51, 51));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/delete-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnDelete->setIcon(icon1);
        btnDelete->setIconSize(QSize(29, 36));
        btnDelete->setCheckable(true);
        btnDelete->setChecked(true);
        btnUndo = new QPushButton(MainWidget);
        btnUndo->setObjectName(QStringLiteral("btnUndo"));
        btnUndo->setEnabled(false);
        btnUndo->setGeometry(QRect(150, 260, 61, 51));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/Undo-icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnUndo->setIcon(icon2);
        btnUndo->setIconSize(QSize(60, 60));
        btnWall = new QPushButton(MainWidget);
        btnWall->setObjectName(QStringLiteral("btnWall"));
        btnWall->setGeometry(QRect(150, 410, 61, 51));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/images/wall.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        btnWall->setIcon(icon3);
        btnWall->setIconSize(QSize(51, 31));
        btnBomb = new QPushButton(MainWidget);
        btnBomb->setObjectName(QStringLiteral("btnBomb"));
        btnBomb->setGeometry(QRect(10, 410, 61, 51));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/images/bomb.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnBomb->setIcon(icon4);
        btnBomb->setIconSize(QSize(30, 30));
        btnRobot = new QPushButton(MainWidget);
        btnRobot->setObjectName(QStringLiteral("btnRobot"));
        btnRobot->setGeometry(QRect(80, 410, 61, 51));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/images/robot.png"), QSize(), QIcon::Normal, QIcon::Off);
        btnRobot->setIcon(icon5);
        btnRobot->setIconSize(QSize(45, 50));
        wdgWorld = new QWidget(MainWidget);
        wdgWorld->setObjectName(QStringLiteral("wdgWorld"));
        wdgWorld->setGeometry(QRect(220, 160, 551, 381));
        wdgWorld->setStyleSheet(QStringLiteral("background-color: white"));
        btnAnimate = new QPushButton(MainWidget);
        btnAnimate->setObjectName(QStringLiteral("btnAnimate"));
        btnAnimate->setGeometry(QRect(50, 180, 111, 41));
        btnAnimate->setCheckable(true);
        label = new QLabel(MainWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 0, 591, 91));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/Fire.gif")));
        label->setScaledContents(true);
        label_2 = new QLabel(MainWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(150, 90, 631, 81));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/images/DanielRecker.png")));
        label_2->setScaledContents(true);

        retranslateUi(MainWidget);

        QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {
        MainWidget->setWindowTitle(QApplication::translate("MainWidget", "World Builder", 0));
        rdbBasic->setText(QApplication::translate("MainWidget", "Basic", 0));
        rdbWand->setText(QApplication::translate("MainWidget", "Wanderer", 0));
        rdbTrack->setText(QApplication::translate("MainWidget", "Tracker", 0));
        btnAnimate->setText(QApplication::translate("MainWidget", "Animate", 0));
        label->setText(QString());
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWIDGET_H
